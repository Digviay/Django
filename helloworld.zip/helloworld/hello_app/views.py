from rest_framework.response import Response
from django.http import HttpResponse


# Create your views here.
def hello(request):
	# data = {"msg": "Hello World"}
	return HttpResponse("Hello World")